import streamlit as st
import pandas as pd
import plotly.graph_objs as go
import os 
import dash_bootstrap_components as dbc
from dash import html

# Load data
col_list = ["AJET_AREA", "ID_LONGITUTE_APT", "ID_LATITUDE_APT", "DS_FLT_APT"]
selected_file = "C:\\Users\\AAK\\Desktop\\asdsad\\query\\aj_ap.xlsx"
df = pd.read_excel(selected_file, usecols=col_list)

# Display title
st.title("Sales Dashboard")

# Data Preview expander
with st.expander("Data Preview"):
    st.dataframe(df)

# Display scatter plot map
ajet_area = df[(df["AJET_AREA"] != "NON_AJET")]
ajet_area["text"] = ajet_area["DS_FLT_APT"] + "," + ajet_area["AJET_AREA"]

fig = go.Figure(data=go.Scattergeo(
    lon=ajet_area["ID_LONGITUTE_APT"],
    lat=ajet_area["ID_LATITUDE_APT"],
    text=ajet_area["text"],
    mode='markers',
    marker=dict(
        size=4,
        color='blue',
    ),
))

fig.update_geos(
    projection_scale=4,
    showcountries=True,
    center=dict(lon=35, lat=40),
    resolution=50,
    showocean=True,
    oceancolor="#D6D6D6",
    landcolor="#F8F8F8",
    countrycolor="#AAAAAA",
    countrywidth=0.5,
    showcoastlines=False
)

fig.update_layout(
    geo_scope='world',
    margin=dict(l=0, r=0, b=0, t=0),
    width=630,
    height=300,
)

st.plotly_chart(fig)
