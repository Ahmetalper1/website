"""
import dash
from dash import dcc
import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import os
import unicodedata
import pandas as pd


cg_first= html.Div(
    dbc.CardGroup(
        [dbc.Card(
            dbc.CardBody([
                html.H4("LF", className= "card_title text-start"),
            dbc.ListGroup([
                dbc.ListGroupItem(["Mevcut Ay",
                    html.Div(
                        [html.I("%2", className="bi bi-caret-up-fill text-success"),
                        " L",
                         html.I("%1.2", className="bi bi-caret-down-fill text-danger"),
                        " B",
                        ],
                    ),
                ]
                ),
                dbc.ListGroupItem("Mevcut Ay      %87"),
            ])
        ], className= "text-center m-0 border-5"),
        className= "p-0 border-4 rounded-3 m-0",)
        ],
    ),
)

layout= dbc.Container(
    children=[dbc.Row(cg_first)
    ], fluid=True,
)
"""