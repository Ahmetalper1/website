import pandas as pd
import teradatasql
from sqlalchemy import create_engine
import csv
import os
import plotly.graph_objects as go

#this is the directory which we will store the fetched csv files
directory = "C:/Users/A_KIZILTUNC/Desktop/temp/"

#teradata connection properties// host= servername // user= AJ teradata account // password= AJ teradata user password
con = teradatasql.connect(
    host='DWH_TERADATA',
    user='UP_DMART_AJ',
    password="AJ_Dmart.2017",
)

#server database query////write your query here (if you want to write the query on rows, just add three " to the start of the query lines ("""))

query = "select ID_ORIGIN_YEAR, ID_ORIGIN_YM, ID_ORIGIN_YMD, ID_ORIGIN_YW, ID_ORIGIN_DAY, DS_MARKET_NETW_REG, DS_MARKET_CITY, ID_MARKET_ROUTE, ID_READING_DAY, SUBSTRING(ID_MARKET_ROUTE from 1 for 3) as HUB, sum(SEAT_CAP), sum(SEAT_CAP_KM) , sum(SEAT_CAP_LAST), sum(SEAT_CAP_KM_LAST), sum(SEAT_SOLD), sum(SEAT_SOLD_KM), sum(SEAT_SOLD_LAST), sum(SEAT_SOLD_KM_LAST), SUBSTRING(ID_MARKET_ROUTE from 1 for 3) as HUB from VP_DWH.DM_ADVANCE_BOOKING_LEG_CABIN_AJ where ID_MARKET_ROUTE like '%(AJ)%' and SEAT_CAP_KM_LAST>0 and SEAT_CAP_KM>0 and SEAT_SOLD_KM_LAST>0 and SEAT_SOLD_KM>0 group by 1,2,3,4,5,6,7,8,9,10 order by ID_READING_DAY;"

#query propeties and writing the query to .csv. Batch size means how many rows will be fetched from database on a single csv file. Batch size is optimized for 16 gb RAM. If you set it to a higher value, you may have ram bottleneck problems. File prefix is going to be the name of the saved csv files. You can change it to your needs.


batch_size= 1000000
file_prefix= "batch"

with con.cursor() as cur:
    cur.execute(query)
    cur.arraysize = batch_size
    batch_num = 1
    while True:
        rows = cur.fetchmany()
        if not rows:
            break
        headers = [desc[0] for desc in cur.description]
        file_name = file_prefix + str(batch_num) + ".csv"
        with open(directory + file_name, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)
        batch_num += 1

#defining the fetched csv files for to ease the further work 

fetchedcsv_files = [os.path.join(directory, f) for f in os.listdir (directory) if f.endswith(".csv")]

#reading csv files then concatenating the csv file to one data frame

dfs = [pd.read_csv(file, index_col=0) for file in fetchedcsv_files]
dfx = pd.concat(dfs)

#this step is not crucial but if you want to optimize the reading and processing speed of the program, you can change the data types according to your data. Skip this step if you don't know what data types you're using. Caution! You may have big data frames that cloges up your ram.

dfx = dfx.astype({"SEAT_SOLD_KM": "int32", "SEAT_SOLD_KM_LAST": "int32", "SEAT_CAP_KM": "int32", "SEAT_CAP_KM_LAST": "int32"})

#dfx.to_csv("C:/Users/o_turk1/Desktop/temp/test5.csv") #---> this is not required to run the program as well but if you want to print the final data frame to a csv just remove the # and set the directory.


#these are the example lines that calculates new columns with the dataframe.

dfx["LF"] = (dfx["SEAT_SOLD_KM"] / dfx["SEAT_CAP_KM"])*100
dfx["LF_L"] = (dfx["SEAT_SOLD_KM_LAST"] / dfx["SEAT_CAP_KM_LAST"])*100

#this prints the ultimate csv file with your manipulated data frame
dfx.to_csv("C:/Users/AAK/Desktop/asdsad/temp/test3.csv")