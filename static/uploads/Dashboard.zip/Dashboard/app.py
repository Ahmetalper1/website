import dash
from dash import dcc
import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import os
import pandas as pd



app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[dbc.themes.COSMO, dbc.icons.BOOTSTRAP, dbc.icons.FONT_AWESOME,"style.css"],
    meta_tags=[{"name": "viewport", "content": "width=device-width"}],
)
app.title = "Anadolujet Dashboard"