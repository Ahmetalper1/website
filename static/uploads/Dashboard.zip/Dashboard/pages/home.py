import dash
from dash import dcc
import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import plotly.express as px
from datafetch import dfx
from app import app

dash.register_page(__name__, path='/', name='Home')



filters_currency = dbc.Card([
    html.Div([
        html.Div(html.H6("CURRENCY", style={"margin-top": "2px"})),
        dcc.RadioItems(['USD', 'TRY',], 'USD', inline=True, labelStyle={"margin-right": "10px"},    inputStyle={"margin-right": "10px"})
    ])
], className="filtercard")

filters_hub = dbc.Card([
    html.Div([
        html.Div(html.H6("HUB")),
        dcc.Dropdown(['SAW', 'ESB', 'DIGER'], 'SAW', id='hub-dropdown', multi = True),
    ])
], className="filtercard")

filters_region = dbc.Card([
    html.Div([
        html.Div(html.H6("AREA")),
        dcc.Dropdown(['KUZEY-DOGU', 'ECN', 'YURTICI', 'BATI'], 'BATI', id='area_dropdown', multi = True),
    ])
], className="filtercard")

filters_opgroup = dbc.Card([
    html.Div([
        html.Div(html.H6("OP GROUP")),
        dcc.Dropdown(['ILAVE', 'TARIFELI'], 'TARIFELI', id='op_group_dropdown', multi = True),
    ])
], className="filtercard")


# first three cards #


card_1 =dbc.Card([
        html.H5("L B EXP", className="basliklbexp"),
        dbc.Card([
                    dbc.Container( children=[
                        dbc.Row(
                            [
                                dbc.Col(html.H6("LF", className="baslikkpi"), width = 3), dbc.Col(html.H5("%89", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("%87.6", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], justify="between", className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("%87.6", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ], )
                ], className="innercardstyle1"),
        dbc.Card([
                    dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("NETREV", className="baslikkpi"), width = 3), dbc.Col(html.H5("654.323.125", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("8.546.321", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("890.323.345", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
                ], className="innercardstyle2"),
        dbc.Card([
                    dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("RASK", className="baslikkpi"), width = 3), dbc.Col(html.H5("5.40", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("3.23", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("7.26", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
        ], className="innercardstyle3"),
    ], className="cardstyle1")

card_2 = dbc.Card([
    html.H5("L B EXP", className="basliklbexp"),
    html.Div([
    dbc.Card([
        dbc.Container( children=[
                        dbc.Row(
                            [
                                dbc.Col(html.H6("K/Z", className="baslikkpi"), width = 3), dbc.Col(html.H5("5.432.234", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("-41.322.322", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], justify="between", className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("-110.223.323", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ], )
    ], className="innercardstyle1"),
    dbc.Card([
        dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("ASK", className="baslikkpi"), width = 3), dbc.Col(html.H5("654.323.125", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("8.546.321", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("890.323.345", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
    ], className="innercardstyle2"),
    dbc.Card([
         dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("RY", className="baslikkpi"), width = 3), dbc.Col(html.H5("5.40", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("3.23", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("7.26", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
    ], className="innercardstyle3"),
    ])
], className="cardstyle2"
)

card_3 = dbc.Card([
    html.H5("L B EXP", className="basliklbexp"),
    html.Div([
    dbc.Card([
         dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("KONMA", className="baslikkpi"), width = 3), dbc.Col(html.H5("2.226", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("12.223", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("110.654", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
    ], className="innercardstyle1"),
    dbc.Card([
       dbc.Container([
                        dbc.Row(
                            [
                                dbc.Col(html.H6("PAX", className="baslikkpi"), width = 3), dbc.Col(html.H5("313.234", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("1.323.563", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                        dbc.Row(
                            [
                                dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("690.434.532", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                            ], className= "g-0 lg-3 gap"),
                    ])
    ], className="innercardstyle2"),
    dbc.Card([
        dbc.Container( children=[
                            dbc.Row(
                                [
                                    dbc.Col(html.H6("TAH. GELIR", className="baslikkpi"), width = 3), dbc.Col(html.H5("5.432.234", className= "datastyle"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                                ], className= "g-0 lg-3 gap"),
                            dbc.Row(
                                [
                                    dbc.Col(html.H6("Mevcut Ay", className="altkpi"), width=3), dbc.Col(html.H4("41.322.322", className= "dsauxpurple"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                                ], justify="between", className= "g-0 lg-3 gap"),
                            dbc.Row(
                                [
                                    dbc.Col(html.H6("Yıl Toplamı", className="altkpi1"), width=3), dbc.Col(html.H4("110.223.323", className= "dsaux2"), width = 3), dbc.Col((html.H4("%2", className="bi bi-caret-up-fill text-success datastylemini"), html.H4("%1.3", className="bi bi-caret-down-fill text-danger datastylemini"), html.H4("%0.7", className="bi bi-caret-down-fill text-danger datastylemini")), width = 4),
                                ], className= "g-0 lg-3 gap"),
                        ], )
    ], className="innercardstyle3"),
    ])
], className="cardstyle3"
)

# scatter plot map #

col_list= ["AJET_AREA", "ID_LONGITUTE_APT", "ID_LATITUDE_APT", "DS_FLT_APT"]

df= pd.read_excel('/Users/A_KIZILTUNC/Desktop/Dashboard/data/aj_ap.xlsx', usecols=col_list)

ajet_area = df[(df["AJET_AREA"] != "NON_AJET")]

ajet_area["text"] = ajet_area["DS_FLT_APT"] + "," + ajet_area["AJET_AREA"]

map = go.Figure(data=go.Scattergeo(
        lon = ajet_area["ID_LONGITUTE_APT"],
        lat = ajet_area["ID_LATITUDE_APT"],
        text= ajet_area["text"],
        mode = 'markers',
        marker=dict(
            size=4,
            color='blue',
        ),
        ))

map.update_geos(
    projection_scale= 4,
    showcountries= True,
    center=dict(lon=35, lat=40),
    resolution= 50,
    showocean= True,
    oceancolor= "#D6D6D6",
    landcolor= "#F8F8F8",
    countrycolor= "#AAAAAA",
    countrywidth= 0.5,
    showcoastlines= False
)

map.update_layout(
        geo_scope='world',
        margin=dict(l=0,r=0,b=0,t=0),
        width = 630,
        height= 300,
        ),

eumap = dbc.Card([dcc.Graph(figure = map)], className="mapcard")


#growth line chart#



'''

gelisim_egrisi = dbc.Card([html.Div(id = 'slider-div', children = 
            [ dcc.Slider(id = 'year-slider',
               min = dfx['ID_READING_DAY'].min(),
               max = dfx['ID_READING_DAY'].max(),
               value = dfx['ID_READING_DAY'].min(),
               marks = { str(year) : str(year) for year in dfx['ID_READING_DAY'].unique() },
               step = None
               )], style = {'width':'50%', 'display':'inline-block'}),
    dcc.Graph(id= "ge_graph")
], className="mapcard")
'''

layout= dbc.Container(
    children=[
    dbc.Row(
        [dbc.Col(card_1), dbc.Col(card_1), dbc.Col(card_2), dbc.Col(card_3)]
    ),
 #   dbc.Row([dbc.Col(eumap), dbc.Col(gelisim_egrisi)])
    ], fluid=True,
)


#callbacks


@app.callback(
    Output("ge_graph", "figure"),
    Input("market-route", "value"),
    Input("year-slider", "value"))
def update_graph(slider_value, market_route):    
    if market_route == "All":
        fdfx = dfx.loc[dfx["ID_READING_DAY"] == slider_value]
    else:
        fdfx = dfx.loc[(dfx["ID_READING_DAY"] == slider_value) & (dfx["ID_MARKET_ROUTE"] == market_route)]

    ge = go.Figure()
    ge.add_trace(go.Scattergl(x="ID_READING_DAY", y="LF", text= fdfx["ID_MARKET_ROUTE"]))
    
    return ge  
