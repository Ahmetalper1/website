import dash
from dash import dcc
import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import os
import unicodedata
import pandas as pd

card_experimental = dbc.Card( children=[
        dbc.Card([
            html.P("LF", className="lead"),
            html.P("Mevcut Ay", className="small"),
            ], className="innercardstyle1")
        ], className="cardstylee d-flex flex-row vh-30 vw-30")

card_experimenta2 = dbc.Card( children=[
        dbc.Card([
            html.P("LF", className="lead"),
            html.P("Mevcut Ay", className="small"),
            ], className="innercardstyle1")
        ], className="cardstylee d-flex flex-row vh-30 vw-30")


layout= dbc.Container(
    children=[
    dbc.Row(
        [dbc.Col(card_experimental, className="md-4"), dbc.Col(card_experimenta2, className="md-4")]
    ),
    ], fluid=True,
)
