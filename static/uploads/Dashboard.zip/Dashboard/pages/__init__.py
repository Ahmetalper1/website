import pages.home
import pages.network
import pages.pg2