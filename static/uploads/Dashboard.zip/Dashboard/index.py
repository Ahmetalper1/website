import dash
from dash import dcc
import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import os
import pandas as pd
import numpy as np

from datafetch import dfx
from app import app
from pages import home, network, pg2


server = app.server

sidebar = html.Div(
    [
        html.Img(src=app.get_asset_url("anadolujet_logocut.png"), height="32px"),
        html.Hr(style={'borderWidth': "15vh", "width": "100%", "borderColor": "#ffff","opacity": "unset"}),
        dbc.Nav(
            [
                dbc.NavLink(dbc.Button("Home", color="primary", className="navlink d-grid gap-2 col-12 mx-auto"), href=app.get_relative_path("/")),
                dbc.NavLink(dbc.Button("Network", color="primary", className="navlink d-grid gap-2 col-12 mx-auto"), href=app.get_relative_path("/network")),
                dbc.NavLink(dbc.Button("test", color="primary", className="navlink d-grid gap-2 col-12 mx-auto"), href=app.get_relative_path("/pg2")),
            ],
            vertical=True,
            pills=True,
        ),
        html.Hr(style={'borderWidth': "15vh", "width": "100%", "borderColor": "#ffff","opacity": "unset"}),
        dbc.Card([
            html.Div([
                html.Div(html.H6("CURRENCY", style={"font-size": "13px"})),
                     dcc.RadioItems(['USD', 'TRY',], 'USD', id="curr-type", inline=True, labelStyle={"margin-right": "10px"},    inputStyle={"margin-right": "10px"})
                    ])
                ], className="filtercard col-10 mx-auto"),
        dbc.Card([
            html.Div([
                html.Div(html.H6("HUB", style={"font-size": "13px"})),
                    dcc.Dropdown(id='hub-type',
                        options= [{"label":i, "value":i} for i in np.append(["All"], dfx["HUB"].unique())],
                        value = "All", multi= True)
            ])], className="filtercard col-10 mx-auto"),
        dbc.Card([
            html.Div([
                html.Div(html.H6("AREA", style={"font-size": "13px"})),
                    dcc.Dropdown(['KUZEY-DOGU', 'ECN', 'YURTICI', 'BATI'], 'BATI', id='area_type', multi = True),
                    ])
                ], className="filtercard col-10 mx-auto"),
        dbc.Card([
            html.Div([
                html.Div(html.H6("MARKET ROUTE", style={"font-size": "13px"})),
                    dcc.Dropdown(id='market-route',
                        options= [{"label":i, "value":str(i)} for i in np.append(["All"], dfx["ID_MARKET_ROUTE"].unique())],
                        value = "All", multi= True)
            ])], className="filtercard col-10 mx-auto"),
        dbc.Card([
            html.Div([
                html.Div(html.H6("OP GROUP", style={"font-size": "13px"})),
                    dcc.Dropdown(['ILAVE', 'TARIFELI'], 'TARIFELI', id='op_group_type', multi = True),
                    ])
                ], className="filtercard col-10 mx-auto"),
    ], 
    className= "SIDEBAR_STYLE",
)

content = html.Div(id="page-content")



app.layout = dbc.Container([
    dbc.Row([
        dcc.Location(id="url"),
        dbc.Col([sidebar], xs=4, sm=4, md=2, lg=2, xl=2, xxl=2),
        dbc.Col([content], xs=8, sm=8, md=10, lg=10, xl=10, xxl=10),
    ])
], fluid=True)

@app.callback(Output('page-content', 'children'), [Input("url", "pathname")])
def display_page(pathname):
    if pathname == '/':
        return home.layout
    if pathname == '/network':
        return network.layout
    if pathname == '/pg2':
        return pg2.layout
    else: # if redirected to unknown link
        return "404 Page Error"

if __name__ == "__main__":
    app.run_server(debug=True)